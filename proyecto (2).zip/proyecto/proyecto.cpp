#include <iostream>
#include <fstream>
#include <string>
#include <windows.h>
#include <stdlib.h>
#include <sstream>
#include<vector>

using namespace std;

string e;
string nomb;
string ex2;
string e3;
void login();
void notas();
void info();
void pronota();
void actunota();
void admin();
void actuinfo();
void nuevoestu();
void nuevainfo(); 
void adminota();
void eliminarestu();
void agregarprof();
void notasnewprof();
void borrarprof();
int main() {
    cout << "+--------------------------------------------------+" << endl;
    cout << "|     Universidad Distrital Francisco Jose De Caldas|" << endl;
    cout << "+--------------------------------------------------+" << endl << endl;
    
    login();

    return 0;
}

void login() {
    int opc, opc1, opc2, opc3, opc4, opc5,opc6,opc7,opc8,opc9,opc10, contra;
    string a, b, ad, conadmin;
    string linea;
    string contra2;
    ifstream inicio;
    string nom;
    ifstream profe;
    string adm;
    ifstream admi;
    string lineax2;
	
    do {
        cout << "\t\tDigite su rol" << endl;
        cout << "1.-Estudiante" << endl;
        cout << "2.-Profesor" << endl;
        cout << "3.-Admin" << endl;
        cout << "4.-Salir" << endl;

        cout << "Escriba la opci�n: ";
        cin >> opc;

        switch (opc) {
            case 1: {
                do {
                    cout << "\t\tINICIO DE ESTUDIANTES" << endl;
                    cout << "Digite su c�digo: ";
                    cin >> a;
                    e = a;
                    a += ".txt";

                    cout << "Digite su contrase�a: ";
                    cin >> b;

                    inicio.open(a.c_str(), ios::in);

                    if (!inicio) {
                        cout << "Usuario incorrecto" << endl;
                        Sleep(2);
                        login();
                    } else {
                        inicio >> linea;

                        if (b == linea) {
                            cout << "\t\tIngreso exitoso" << endl;
                            Sleep(3);
                            cout << "\t\tSelecciona una opci�n" << endl;
                            cout << "1.1.-Ver notas" << endl;
                            cout << "1.3.-Salir" << endl;
                            cout << "Escriba la opci�n: ";
                            cin >> opc1;
                        } else {
                            cout << "Contrase�a incorrecta" << endl;
                            Sleep(2);
                            login();
                        }
                    }

                    switch (opc1) {
                        case 1: {
                            cout << "\t\t\tBIENVENIDO" << endl;
                            notas();
                            cout<<""<<endl;                          		
                            cout << "1.2 -Salir" << endl;
                            cout << "Escriba la opci�n: ";
                            cin >> opc2;
                            if (opc2 == 1) {
                                cout << "1.2.-Info personal" << endl;
                                cout << "1.3.-Salir" << endl;
                                cin >> opc3;
                                if (opc3 == 1) {
                                    info();
                                } else if (opc3 == 3) {
                                    login();
                                }
                            }
                            break;
                        }
                    }

                    inicio.close();
                } while (opc1 != 3 && opc2 != 2);
                break;
            }
            case 2: {
                cout << "\t\tINICIO DE PROFESORES" << endl;
                cout << "Digite su nombre: ";
                cin >> nom;
                nomb = nom;
                nom += ".txt";
                cout << "Digite su contrase�a: ";
                cin >> contra;
                stringstream ss;
                ss << contra;
                string contraStr = ss.str();
                profe.open(nom.c_str(), ios::in);
                if (profe.fail()) {
                    cout << "Usuario incorrecto" << endl;
                    Sleep(2);
                    login();
                } else {
                    profe >> contra2;
                    if (contraStr == contra2) {
                        cout << "\t\tIngreso exitoso" << endl;
                        Sleep(3);
                        cout << "\t\tSelecciona una opci�n" << endl;
                        cout << "2.1.-Ver notas de un estudiante" << endl;
                        cout << "2.2.Salir" << endl;
                        cout << "Escriba la opci�n: ";
                        cin >> opc3;
                        switch (opc3) {
                            case 1: {
                                do {
                                    cout << "Digite el c�digo del estudiante del que desea ver las notas: ";
                                    cin >> a;
                                    e = a;
                                    a += ".txt";
                                    inicio.open(a.c_str(), ios::in);
                                    if (a == "0") {
                                        login();
                                    } else if (inicio.fail()) {
                                        cout << "No se encontr� el estudiante, por favor digite otra vez el codigo" << endl;
                                        Sleep(3);
                                        inicio.close();
                                    } else {
                                        pronota();
                                        do {
                                            cout << "Digite una opci�n" << endl;
                                            cout << "2.1.-Editar una nota" << endl;
                                            cout << "2.2.Salir" << endl;
                                            cin >> opc4;
                                            switch (opc4) {
                                                case 1: {
													actunota();
                                                    break;
                                                }
                                            }
                                        } while (opc4 != 2);
                                    }
                                } while (inicio.fail());
                                break;
                            }
                            case 2: {
								login();
                                break;
                            
                            }
                           
                        }
                    } 
					else {
                        cout << "Contrase�a incorrecta" << endl;
                        Sleep(2);
                        login();
                    }
                }

                break;
            }
            case 3: {
                cout << "\t\t INICIO ADMIN " << endl;
                cout << "digite su codigo administrador" << endl;
                cin >> ad;
                adm = ad;
                ad += ".txt";
                cout << "digite su contrase�a" << endl;
                cin >> conadmin;
                admi.open(ad.c_str(), ios::in);
                if (admi.fail()) {
                    cout << "usuario no encontrado" << endl;
                    Sleep(3);
                    login();
                } else {
                    admi >> lineax2;
                    if (conadmin == lineax2) {
						do{
						
                        cout << "\t\t INGRESO EXITOSO" << endl;
                        Sleep(3);
                        cout << "\t\tdigite una opcion" << endl;
                        cout << "3.1.-Ver info de estudiantes" << endl;
                        cout << "3.2.-Agregar estudiante" << endl;
                        cout << "3.3.-Ver nota de estudiante" << endl;
                        cout << "3.4.-Eliminar estudiante" << endl;
                        cout<<"3.5-Agregar profesor"<<endl;
                        cout<<"3.6-Eliminar profesor"<<endl;
                        cout<<"3.7-Salir"<<endl;
                        cout << "Escriba la opci�n: ";
                        cin>>opc5;
                        switch(opc5){
                        	case 1:{
                        		do {
                                    cout << "Digite el c�digo del estudiante del que desea ver la info personal: ";
                                    cin >> a;
                                    e = a;
                                    a += ".txt";
                                    inicio.open(a.c_str(), ios::in);
                                    if (a == "0") {
                                        login();
                                    } else if (inicio.fail()) {
                                        cout << "No se encontr� el estudiante, por favor digite otra vez el codigo" << endl;
                                        Sleep(3);
                                        inicio.close();
                                    }
                                    else{
                                    	info();
                                    }
                                   
                                	} while (inicio.fail());
                                	cout << "3.1.-Modificar info" << endl;
                        			cout << "3.2.-Salir" << endl;
                        			cout << "Escriba la opci�n: ";
                        			cin>>opc6;
                        			switch(opc6){
                        				case 1:{
                        					actuinfo();
                        					break;
                        				}
                        				case 2:{
                        					Sleep(3);
                        					break;
                        				}
                        			}
                        		break;
                        		}
                        	case 2:{
                        			nuevoestu();
                        			cout<<"3.1.1.-Agregar info personal nueva"<<endl;
                        			cout<<"3.1.2.-Salir"<<endl;               											
                        			cout<<"Escriba la opcion"<<endl;
                        			cin>>opc7;
                        			switch(opc7){
                        				case 1:{
                        					nuevainfo();
                        					break;
                        				}
                        				case 2:{
                        					Sleep(3);
                        					break;
                        				}
                        			}
                        			break;
                        		}
                        		case 3:{
                        			
                        			do {
                                    cout << "Digite el c�digo del estudiante del que desea ver las notas personal: ";
                                    cin >> a;
                                    e = a;
                                    a += ".txt";
                                    inicio.open(a.c_str(), ios::in);
                                    if (a == "0") {
                                        login();
                                    } else if (inicio.fail()) {
                                        cout << "No se encontr� el estudiante, por favor digite otra vez el codigo" << endl;
                                        Sleep(3);
                                        inicio.close();
                                    }
                                    else{
                                    	notas();
                                    	cout<<"3.3.1-Editar una nota"<<endl;
                                    	cout<<"3.3.2-Salir"<<endl;
                                    	cout<<"Escriba la opcion:"<<endl;
                                    	cin>>opc8;
                                    	switch(opc8){
                                    		case 1:{
                                    			adminota();
                                    			break;
                                    		}
                                    		case 2:{
                                    			Sleep(3);
                                    			break;
                                    		}
                                    	}
                                    }
                                    
                                	} while (inicio.fail());
                        			break;
                        		}
                        		case 4:{
                        			eliminarestu();
                        			break;
                        		}
                        		case 5:{
                        			agregarprof();
                        			cout<<"3.5.1-Agregar las notas del nuevo profesor"<<endl;
                        			cout<<"3.5.2-Salir"<<endl;
                        			cout<<"Escriba la opcion"<<endl;
                        			cin>>opc9;
                        			switch(opc9){
                        				case 1:{
                        					notasnewprof();
                        					break;
                        				}
                        				case 2:{
                        					Sleep(3);
                        					break;
                        				}
                        			}
                        			break;
                        		}
                        		case 6:{
                        			borrarprof();
                        			
                        			break;
                        		}
                        		case 7:{
                        			Sleep(3);
                        			break;
                        		}
                        	}
                    	}while(opc5!=7);
                    }
                }
                break;
            }
        }
    } while (opc != 4);
}

void notas() {		//Mostrar las notas;
    string linea;
    ifstream notas;
    e += "_notas.txt";
    notas.open(e.c_str(), ios::in);

    while (getline(notas, linea)) {
        cout << linea << endl;
    }

    notas.close();
}

void info() {	//Mostrar la info personal de los estudiantes;
    string linea;
    ifstream info;
    e += "_info.txt";
    info.open(e.c_str(), ios::in);
	if(!info){
		cout<<"no se ha abierto el archivo"<<endl;
	}
	if(info.fail()){
		cout << "No se encontr� el estudiante" << endl;
		info.close();
		return;
		
	}
	else{
		while (getline(info, linea)) {
        cout << linea << endl;
    }
	}

    info.close();
}

void pronota() {	//Mostrarle al profesor las notas;
    string linea;
    ifstream pronot;
    nomb += "_nota.txt";
    pronot.open(nomb.c_str(), ios::in);
    if(!pronot){
    	cout<<"no se ha abierto el archivo"<<endl;
    }
    if (pronot.fail()) {
        cout << "No se encontr� el estudiante" << endl;
        pronot.close();
        return;
    } else {

        while (getline(pronot, linea)) {
            cout << linea << "\n";
        }
    }
    pronot.close();
}

void actunota() {	//Mostrar las notas actualizadas
			
    string editnota = nomb;
    ifstream edit(editnota.c_str());
   
    vector<string> noti;
    string linea;
    int ind;
    string newnota;
	cout << "Ruta del archivo: " << editnota << endl;
    if (!edit) {
        cout << "No se pudo abrir el archivo" << endl;
        return;
    }

    while (getline(edit, linea)) {
        noti.push_back(linea);
    }
    
    edit.close();

    cout << "Digite el �ndice para el cambio de nota(siempre va a ser el indice+1) ";
    
    cin >> ind;
    if (ind < 1 || ind > noti.size()) {
        cout << "No existe tal nota" << endl;
        return;
    }

    cout << "Digite la nueva nota: ";
    cin >> newnota;

    noti[ind - 1] = newnota;

    ofstream notaactu(editnota.c_str(), ios::out|ios::trunc ); 
    for (size_t i = 0; i < noti.size(); ++i) {
        const string& nota = noti[i];
        notaactu << nota << endl;
    }
    notaactu.close();
    cout << "Nota actualizada correctamente" << endl;

    cout << "Notas actualizadas:" << endl;
    for (size_t i = 0; i < noti.size(); i++) {
        cout << noti[i] << endl;
    }
}
void actuinfo(){	//Mostrar info actualizada;
	string editinfo= e;
	ifstream infod(editinfo.c_str());	
	vector<string> infi;
	string linea;
	int ind;
	string newinfo;
	cout<<"la ruta del archivo es"<<editinfo<<endl;
	if(!infod){
		cout<<"no se puede abrir el archivo"<<endl;
		return;
	}
	while (getline(infod, linea)) {
        infi.push_back(linea);
    }
    infod.close();
    cout << "Digite el �ndice para el cambio de info(recuerde poner la caracteristica antes del cambio de info,ej=nombre:)"<<endl;
    cout<<"tenga en cuenta que si agrego el estudiante va a ser el indice+1"<<endl;
    cin >> ind;
     if (ind < 1 || ind > infi.size()) {
        cout << "No existe tal informacion" << endl;
        return;
    }
    cin.ignore();
    cout << "Digite la nueva info: ";
    getline(cin,newinfo);
    infi[ind - 1] = newinfo;
	ofstream infoactu(editinfo.c_str(), ios::out|ios::trunc ); 
    for (size_t i = 0; i < infi.size(); ++i) {
        const string& infa = infi[i];
        infoactu << infa << endl;
    }
    infoactu.close();
    cout << "info actualizada correctamente" << endl;

    cout << "Info actualizada:" << endl;
    for (size_t i = 0; i < infi.size(); i++) {
        cout << infi[i] << endl;
    }
}
void nuevoestu(){	//Crear nuevo estudiante;
	string nuevo;
	cout<<"Digite el codigo del nuevo estudiante :"<<endl;
	cin>>nuevo;
	ex2=nuevo;
	nuevo+=".txt";
	ofstream news(nuevo.c_str());
	if(news.is_open()){
		string linea;
		cout<<"Ingrese la contrase�a del estudiante nuevo('fin' para terminar ):\n"<<endl;
	  
	while(getline(cin,linea)&&linea!="fin"){
		news<<linea<<endl;
		}
		news.close();
		cout<<"se ha creado el estudiante"<<endl;
	}
	else{
		cout<<"no se creo el estudiante"<<endl;
	}
	
}
void nuevainfo(){	//Crear nueva info del nuevo estudiante;
	string infoS;
	cout<<"Digite el codigo del estudiante"<<endl;
	cin>>infoS;
	e3=infoS;
	infoS+="_info.txt";
	ofstream Ninfo(infoS.c_str());
	if(Ninfo.is_open()){
		string linea;
		cout<<"Ingrese la info del estudiante nuevo('fin' para terminar ):\n"<<endl;
				while(getline(cin,linea)&&linea!="fin"){
				Ninfo<<linea<<endl;
					}
			Ninfo.close();
			cout<<"se ha creado la informacion del estudiante"<<endl;
	}
	else{
		cout<<"no se creo la informacion del estudiante"<<endl;
	}
}
void adminota(){	//Actualizar notas;
	string adnota= e;
	ifstream notaad(adnota.c_str());	
	vector<string> notid;
	string linea;
	int ind;
	string newnotad;
	cout<<"la ruta del archivo es"<<adnota<<endl;
	if(!notaad){
		cout<<"no se puede abrir el archivo"<<endl;
		return;
	}
	while (getline(notaad, linea)) {
        notid.push_back(linea);
    }
    notaad.close();
    cout << "Digite el �ndice para el cambio de info(recuerde poner la nota a la que corresponde)"<<endl;
    cin >> ind;
     if (ind < 1 || ind > notid.size()) {
        cout << "No existe tal nota" << endl;
        return;
    }
    cin.ignore();
    cout << "Digite la nueva nota: ";
    getline(cin,newnotad);
    notid[ind - 1] = newnotad;
	ofstream notadin(adnota.c_str(), ios::out|ios::trunc ); 
    for (size_t i = 0; i < notid.size(); ++i) {
        const string& notadd = notid[i];
        notadin << notadd << endl;
    }
    notadin.close();
    cout << "info actualizada correctamente" << endl;

    cout << "Info actualizada:" << endl;
    for (size_t i = 0; i < notid.size(); i++) {
        cout << notid[i] << endl;
    }
}
void eliminarestu(){
	string eliminar;
	
	cout<<"ingrese el codigo del estudiante que desea eliminar"<<endl;
	cin>>eliminar;
	eliminar+=".txt";
	if(remove(eliminar.c_str())!=0){
		cout<<"no se elimino el estudiante"<<endl;
		
		
	}
	else{
		cout<<"se elimino el estudiante con el codigo: "<< eliminar<<endl;
		
	}
}
void agregarprof(){	//Nuevo profesor;
	string nuevo;
	cout<<"Digite el nombre del nuevo profesor :"<<endl;
	cin>>nuevo;
	ex2=nuevo;
	nuevo+=".txt";
	ofstream news(nuevo.c_str());
	if(news.is_open()){
		string linea;
		cout<<"Ingrese la contrase�a del profesor nuevo('fin' para terminar ):\n"<<endl;
	  
	while(getline(cin,linea)&&linea!="fin"){
		news<<linea<<endl;
		}
		news.close();
		cout<<"se ha creado el profesor nuevo"<<endl;
	}
	else{
		cout<<"no se creo el profesor"<<endl;
	}
}
void notasnewprof(){	//Notas del nuevo profesor;
	string infoS;
	cout<<"Digite el nombre del profesor"<<endl;
	cin>>infoS;
	e3=infoS;
	infoS+="_nota.txt";
	ofstream Ninfo(infoS.c_str());
	if(Ninfo.is_open()){
		string linea;
		cout<<"Ingrese la materia y las notas del nuevo profesor('fin' para terminar ):\n"<<endl;
				while(getline(cin,linea)&&linea!="fin"){
				Ninfo<<linea<<endl;
					}
			Ninfo.close();
			cout<<"se han subido las notas correctamente"<<endl;
	}
	else{
		cout<<"no se subio la nota correctamente"<<endl;
	}
}
void borrarprof(){
	string eliminar;

	cout<<"ingrese el nombre del profesor que desea eliminar"<<endl;
	cin>>eliminar;
	eliminar+=".txt";
	if(remove(eliminar.c_str())!=0){
		cout<<"no se elimino el profesor"<<endl;
		
		
	}
	else{
		cout<<"se elimino el profesor: "<< eliminar<<endl;
		
	}
}









